(function(){Meteor.startup(function() {
  SyncedCron.start();
});

})();
