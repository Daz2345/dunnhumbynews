(function(){Posts._ensureIndex({"status": 1, "postedAt": 1});
Comments._ensureIndex({"postId": 1});

})();
