(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['telescope-messages'] = {};

})();

//# sourceMappingURL=telescope-messages.js.map
